// src/components/Navbar.js
import { ShoppingCart } from 'lucide-react';
import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
const Navbar = () => {
    const cartItems = useSelector(state => state.cart.items);
     
  return (
    <nav className="bg-gray-800 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-white text-lg">E Commerce App</div>
        <div className="space-x-4 flex items-center gap-4">
          <Link to="/" className="text-gray-300 hover:text-white">Home</Link>
          <Link to="/product" className="text-gray-300 hover:text-white">Product</Link>
          <Link to="/login" className="text-gray-300 hover:text-white">Login</Link>
          <div className="relative">
          <Link to="/cart" className="flex items-center">
          <ShoppingCart className="w-6 h-6 text-white" />
          {cartItems.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full h-4 w-4 flex justify-center items-center text-xs">
              {cartItems.length}
            </span>
          )}
        </Link>
      </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
