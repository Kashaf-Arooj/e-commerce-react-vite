import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
const Home = () => {
  const navigate = useNavigate();
    const URL = "https://fakestoreapi.com/products";
    const [products, setProducts] = useState([]); // State to store products

    useEffect(() => {
        // Fetch data when the component mounts
        fetch(URL)
            .then((response) => response.json())
            .then((data) => {
                setProducts(data); // Store fetched data in state
            })
            .catch((error) => {
                console.log(error); // Log any errors
            });
    }, []); // Empty dependency array ensures this runs only once

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {products.map((product) => (
                <div key={product.id} className="border rounded-lg p-4 shadow-md cursor-pointer" onClick={()=>navigate(`/product/${product.id}`)}>
                    <img src={product.image} alt={product.title} className="w-full h-48 object-cover rounded" />
                    <h2 className="text-lg font-bold mt-2">{product.title}</h2>
              
                    <p className="text-xl font-semibold mt-2">${product.price}</p>
                </div>
            ))}
        </div>
    );
};

export default Home;


