// src/pages/Cart.js
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart } from '../redux/cart-slice';

const Cart = () => {
  const cartItems = useSelector((state) => state.cart.items);  
  const dispatch = useDispatch();
    
  const handleRemoveFromCart = (id) => {
     console.log('current id in component is ',id)
    dispatch(removeFromCart(id));  
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Shopping Cart</h1>
      {cartItems.length === 0 ? (
        <div>Your cart is empty.</div>
      ) : (
        <div>
          {cartItems.map((item,index) => (
            <div key={index} className="flex items-center justify-between border-b py-4">
              <div className="flex items-center">
                <img src={item.image} alt={item.title} className="w-16 h-16 object-cover mr-4" />
                <div>
                  <h2 className="font-bold">{item.title}</h2>
                  <p className="text-gray-700">${item.price}</p>
                </div>
              </div>
              <button 
                className="bg-red-600 text-white py-1 px-3 rounded hover:bg-red-700"
                onClick={() => handleRemoveFromCart(item.id)}
              >
                Remove 
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Cart;
